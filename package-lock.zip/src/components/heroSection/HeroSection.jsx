import React from 'react'

function HeroSection() {
  return (
		<div>
			<img
				src="https://images.squarespace-cdn.com/content/v1/5e7275120157e10f58ad3274/a85f6bc5-0992-44f9-b2b2-1d2d5a17fbd8/Back+To+School+Sale+Round-Up+%282%29.jpg"
				alt="Banner"
        width="100%"
			/>
		</div>
  );
}

export default HeroSection